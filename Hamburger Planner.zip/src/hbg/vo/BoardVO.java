package hbg.vo;

public class BoardVO {
	/* service */
	private int user_no;
	private int board_no;
	private String user_grade;
	private int board_order;
	private String board_title;
	/* board */
	private String board_type;
	private String board_auth;
	private String board_update;
	private String board_regdate;
	/* memo */
	private String memo_content;
	/* checklist */
	private int clist_check1;
	private String clist_content1;
	private int clist_check2;
	private String clist_content2;
	private int clist_check3;
	private String clist_content3;
	private int clist_check4;
	private String clist_content4;
	private int clist_check5;
	private String clist_content5;
	/* calendar */
	private String cldar_date;
	private int cldar_order;
	private String cldar_title;
	private String cldar_content;
	
	public int getUser_no() {
		return user_no;
	}
	public void setUser_no(int user_no) {
		this.user_no = user_no;
	}
	public int getBoard_no() {
		return board_no;
	}
	public void setBoard_no(int board_no) {
		this.board_no = board_no;
	}
	public String getUser_grade() {
		return user_grade;
	}
	public void setUser_grade(String user_grade) {
		this.user_grade = user_grade;
	}
	public int getBoard_order() {
		return board_order;
	}
	public void setBoard_order(int board_order) {
		this.board_order = board_order;
	}
	public String getBoard_title() {
		return board_title;
	}
	public void setBoard_title(String board_title) {
		this.board_title = board_title;
	}
	public String getBoard_type() {
		return board_type;
	}
	public void setBoard_type(String board_type) {
		this.board_type = board_type;
	}
	public String getBoard_auth() {
		return board_auth;
	}
	public void setBoard_auth(String board_auth) {
		this.board_auth = board_auth;
	}
	public String getBoard_update() {
		return board_update;
	}
	public void setBoard_update(String board_update) {
		this.board_update = board_update;
	}
	public String getBoard_regdate() {
		return board_regdate;
	}
	public void setBoard_regdate(String board_regdate) {
		this.board_regdate = board_regdate;
	}
	public String getMemo_content() {
		return memo_content;
	}
	public void setMemo_content(String memo_content) {
		this.memo_content = memo_content;
	}
	public int getClist_check1() {
		return clist_check1;
	}
	public void setClist_check1(int clist_check1) {
		this.clist_check1 = clist_check1;
	}
	public String getClist_content1() {
		return clist_content1;
	}
	public void setClist_content1(String clist_content1) {
		this.clist_content1 = clist_content1;
	}
	public int getClist_check2() {
		return clist_check2;
	}
	public void setClist_check2(int clist_check2) {
		this.clist_check2 = clist_check2;
	}
	public String getClist_content2() {
		return clist_content2;
	}
	public void setClist_content2(String clist_content2) {
		this.clist_content2 = clist_content2;
	}
	public int getClist_check3() {
		return clist_check3;
	}
	public void setClist_check3(int clist_check3) {
		this.clist_check3 = clist_check3;
	}
	public String getClist_content3() {
		return clist_content3;
	}
	public void setClist_content3(String clist_content3) {
		this.clist_content3 = clist_content3;
	}
	public int getClist_check4() {
		return clist_check4;
	}
	public void setClist_check4(int clist_check4) {
		this.clist_check4 = clist_check4;
	}
	public String getClist_content4() {
		return clist_content4;
	}
	public void setClist_content4(String clist_content4) {
		this.clist_content4 = clist_content4;
	}
	public int getClist_check5() {
		return clist_check5;
	}
	public void setClist_check5(int clist_check5) {
		this.clist_check5 = clist_check5;
	}
	public String getClist_content5() {
		return clist_content5;
	}
	public void setClist_content5(String clist_content5) {
		this.clist_content5 = clist_content5;
	}
	public String getCldar_date() {
		return cldar_date;
	}
	public void setCldar_date(String cldar_date) {
		this.cldar_date = cldar_date;
	}
	public int getCldar_order() {
		return cldar_order;
	}
	public void setCldar_order(int cldar_order) {
		this.cldar_order = cldar_order;
	}
	public String getCldar_title() {
		return cldar_title;
	}
	public void setCldar_title(String cldar_title) {
		this.cldar_title = cldar_title;
	}
	public String getCldar_content() {
		return cldar_content;
	}
	public void setCldar_content(String cldar_content) {
		this.cldar_content = cldar_content;
	}
	
}